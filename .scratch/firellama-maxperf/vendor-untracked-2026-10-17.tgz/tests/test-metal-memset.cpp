// Fills a sub-range of a backend buffer and checks the bytes outside it.
//
// The Metal path built the fill range with NSMakeRange(offs, offs + size). NSRange is
// (location, length), so the length was the END offset and the fill ran `offs` bytes past
// the region the caller asked for. A call with a non-zero offset therefore overwrote the
// tail of the tensor, and on the last tensor in a buffer it ran past the buffer itself.
//
// Nothing in a text forward pass calls memset_tensor at a non-zero offset, so the backend
// suite never caught it. This test does, on whichever backend is passed on the command
// line (MTL0 to run the Metal path).

#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"

#include <cstdio>
#include <cstring>
#include <vector>

static int g_fail = 0;

static void check(bool ok, const char * what) {
    if (!ok) {
        printf("  FAIL %s\n", what);
        g_fail++;
    }
    printf("  %s %s\n", ok ? "ok  " : "FAIL", what);
}

// One region filled, with guard bytes on both sides that must not move.
static void test_one(ggml_backend_t backend, int64_t nbytes, size_t offset, size_t size, uint8_t value) {
    printf("nbytes=%lld offset=%zu size=%zu value=%u\n",
           (long long) nbytes, offset, size, (unsigned) value);

    struct ggml_init_params params = {
        /*.mem_size   =*/ ggml_tensor_overhead(),
        /*.mem_buffer =*/ NULL,
        /*.no_alloc   =*/ true,
    };

    struct ggml_context * ctx = ggml_init(params);

    struct ggml_tensor * t = ggml_new_tensor_1d(ctx, GGML_TYPE_I8, nbytes);
    ggml_set_name(t, "memset_target");

    ggml_backend_buffer_t buf = ggml_backend_alloc_ctx_tensors(ctx, backend);
    check(buf != NULL, "buffer allocated");
    if (buf == NULL) {
        ggml_free(ctx);
        return;
    }

    // A known pattern everywhere, so a byte that moves is detectable regardless of value.
    const uint8_t seed = 0xA5;
    std::vector<uint8_t> host(nbytes, seed);
    ggml_backend_tensor_set(t, host.data(), 0, nbytes);

    ggml_backend_tensor_memset(t, value, offset, size);
    ggml_backend_synchronize(backend);

    std::vector<uint8_t> out(nbytes, 0);
    ggml_backend_tensor_get(t, out.data(), 0, nbytes);

    size_t bad_before = 0;
    for (size_t i = 0; i < offset; i++) {
        if (out[i] != seed) bad_before++;
    }

    size_t bad_inside = 0;
    for (size_t i = offset; i < offset + size; i++) {
        if (out[i] != value) bad_inside++;
    }

    size_t bad_after = 0;
    for (size_t i = offset + size; i < (size_t) nbytes; i++) {
        if (out[i] != seed) bad_after++;
    }

    char msg[256];
    snprintf(msg, sizeof(msg), "bytes before the range untouched (offset %zu, %zu clobbered)", offset, bad_before);
    check(bad_before == 0, msg);
    snprintf(msg, sizeof(msg), "bytes inside the range filled (%zu unfilled of %zu)", bad_inside, size);
    check(bad_inside == 0, msg);
    snprintf(msg, sizeof(msg), "bytes after the range untouched (%zu clobbered)", bad_after);
    check(bad_after == 0, msg);

    ggml_backend_buffer_free(buf);
    ggml_free(ctx);
}

// The shape DSV4 actually produces. `dsv4_clear_tensor_stream` clears one stream of a
// KV tensor with `memset(tensor, 0, stream*stream_size, stream_size)`, so consecutive
// streams sit next to each other in one buffer. With the pre-fix `NSMakeRange(offs,
// offs + size)` the fill ran `offs` bytes past the region, which for stream n lands at
// the head of stream n+1 -- so clearing one stream silently zeroes the next one's cache.
//
// The single-tensor test above catches the overrun as guard bytes inside one tensor.
// This one catches it as a neighbour being damaged, which is what a user would see.
static void test_adjacent_streams(ggml_backend_t backend) {
    const int n_streams = 8;
    const size_t stream_size = 512;
    const size_t nbytes = (size_t) n_streams * stream_size;

    printf("adjacent streams: %d x %zu bytes in one buffer\n", n_streams, stream_size);

    struct ggml_init_params params = {
        /*.mem_size   =*/ ggml_tensor_overhead()*(n_streams + 1),
        /*.mem_buffer =*/ NULL,
        /*.no_alloc   =*/ true,
    };
    struct ggml_context * ctx = ggml_init(params);

    // Allocated together, so the buffer lays them out contiguously like the real KV cache.
    struct ggml_tensor * t[8];
    for (int i = 0; i < n_streams; i++) {
        t[i] = ggml_new_tensor_1d(ctx, GGML_TYPE_I8, (int64_t) stream_size);
        char name[32];
        snprintf(name, sizeof(name), "stream_%d", i);
        ggml_set_name(t[i], name);
    }

    ggml_backend_buffer_t buf = ggml_backend_alloc_ctx_tensors(ctx, backend);
    check(buf != NULL, "buffer allocated");
    if (buf == NULL) { ggml_free(ctx); return; }

    const uint8_t seed = 0xA5;

    // One KV tensor holding every stream, as the real cache does. `dsv4_clear_tensor_stream`
    // clears stream n with `memset(tensor, 0, n*stream_size, stream_size)`, so the offset is
    // non-zero and the pre-fix fill ran n*stream_size bytes past the region.
    struct ggml_tensor * kv = ggml_new_tensor_1d(ctx, GGML_TYPE_I8, (int64_t) nbytes);
    ggml_set_name(kv, "kv_streams");
    ggml_backend_buffer_free(buf);
    buf = ggml_backend_alloc_ctx_tensors(ctx, backend);
    if (buf == NULL) { check(false, "buffer re-allocated for the single KV tensor"); ggml_free(ctx); return; }

    // A non-zero byte everywhere, so a zeroed byte is attributable to the memset. Clearing
    // every stream instead would hide the bug: overfilled regions get zeroed twice anyway.
    std::vector<uint8_t> pat(nbytes, seed);
    for (size_t k = 0; k < nbytes; k++) {
        pat[k] = (uint8_t) (0x10 + (k % 0x60));   // 0x10..0x6F, never 0x00
    }
    ggml_backend_tensor_set(kv, pat.data(), 0, nbytes);

    // Clear one middle stream. Stream 0 has offset 0 and is unaffected either way, which is
    // why this bug only shows from stream 1 on. Stream 1 is where the arithmetic is smallest
    // and clearest: offs = 512, so pre-fix the fill ran to 512 + 512 + 512 = 1536 and took
    // all of stream 2 with it.
    const int target = 1;
    ggml_backend_tensor_memset(kv, 0x00, (size_t) target * stream_size, stream_size);
    ggml_backend_synchronize(backend);

    std::vector<uint8_t> out(nbytes, 0);
    ggml_backend_tensor_get(kv, out.data(), 0, nbytes);

    size_t not_zero = 0;
    for (size_t k = 0; k < stream_size; k++) {
        if (out[(size_t) target * stream_size + k] != 0x00) not_zero++;
    }

    // Every byte outside the target stream must still hold what was written before. Pre-fix,
    // stream 2 comes back entirely zero.
    int streams_damaged = 0;
    for (int n = 0; n < n_streams; n++) {
        if (n == target) continue;
        for (size_t k = 0; k < stream_size; k++) {
            uint8_t want = (uint8_t) (0x10 + ((size_t) n * stream_size + k) % 0x60);
            if (out[(size_t) n * stream_size + k] != want) { streams_damaged++; break; }
        }
    }

    char msg[160];
    snprintf(msg, sizeof(msg), "the cleared stream is zero (%zu bytes not zero)", not_zero);
    check(not_zero == 0, msg);
    snprintf(msg, sizeof(msg),
             "clearing stream %d left the other %d alone (%d damaged)",
             target, n_streams - 1, streams_damaged);
    check(streams_damaged == 0, msg);

    ggml_backend_buffer_free(buf);
    ggml_free(ctx);
}

int main(int argc, char ** argv) {
    const char * backend_name = argc > 1 ? argv[1] : "MTL0";

    ggml_backend_t backend = ggml_backend_init_by_name(backend_name, nullptr);
    if (backend == NULL) {
        printf("no backend named '%s'\n", backend_name);
        return 77; // skipped
    }
    printf("backend: %s (%s)\n", backend_name, ggml_backend_name(backend));

    // offset 0: the length bug is invisible, the fill is already right-sized.
    test_one(backend, 4096,    0,  256, 0x00);
    // A non-zero offset is the whole point: pre-fix this overfilled by `offset` bytes.
    test_one(backend, 4096, 1024,  256, 0xFF);
    test_one(backend, 4096, 3584,  256, 0x5A);
    // Offset past the halfway point, so an overfill runs to the end of the tensor.
    test_one(backend, 4096, 4000,   16, 0x11);
    // Fills the tail exactly: nothing after it, so only a short size is caught.
    test_one(backend, 4096, 2048, 2048, 0x7E);

    // The production shape: consecutive streams of a KV tensor in one buffer.
    test_adjacent_streams(backend);

    ggml_backend_free(backend);

    if (g_fail) {
        printf("FAILED: %d check(s)\n", g_fail);
        return 1;
    }
    printf("all checks passed\n");
    return 0;
}
